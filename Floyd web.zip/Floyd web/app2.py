from flask import Flask, render_template, request
import heapq
import time

app = Flask(__name__)

def baca_data(filename):
    file = open(filename, "r")
    graph = {}
    text = file.readline().replace("\n", "")
    while text != "":
        if text.strip():
            text = text.strip().split()
            node1, node2, weight = text[0], text[1], int(text[2])
            if node1 not in graph:
                graph[node1] = {}
            if node2 not in graph:
                graph[node2] = {}
            graph[node1][node2] = weight
            graph[node2][node1] = weight
        text = file.readline().replace("\n", "")
    file.close()
    return graph

def floyd_warshall(graph, start, finish):
    # Inisialisasi matriks jarak
    nodes = list(graph.keys())
    n = len(nodes)
    distances = [[float('inf')] * n for _ in range(n)]
    next = [[None] * n for _ in range(n)]

    # Mengisi matriks jarak awal
    for i in range(n):
        distances[i][i] = 0
    for node1 in graph:
        for node2, weight in graph[node1].items():
            node1_index = nodes.index(node1)
            node2_index = nodes.index(node2)
            distances[node1_index][node2_index] = weight
            next[node1_index][node2_index] = node2

    # Algoritma Floyd-Warshall
    start_time = time.time()  # Waktu mulai eksekusi algoritma
    for k in range(n):
        for i in range(n):
            for j in range(n):
                if distances[i][j] > distances[i][k] + distances[k][j]:
                    distances[i][j] = distances[i][k] + distances[k][j]
                    next[i][j] = next[i][k]
    end_time = time.time()  # Waktu selesai eksekusi algoritma
    execution_time = end_time - start_time  # Menghitung waktu eksekusi

    # Membangun jalur terpendek dari start ke finish
    start_index = nodes.index(start)
    finish_index = nodes.index(finish)
    path = [start]
    distance = distances[start_index][finish_index]
    while start_index != finish_index:
        start_index = nodes.index(next[start_index][finish_index])
        path.append(nodes[start_index])

    return path, distance, execution_time

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/result', methods=['POST'])
def result():
    start = request.form['start']
    finish = request.form['finish']
    graph = baca_data("graph.txt")
    shortest_path, shortest_distance, execution_time = floyd_warshall(graph, start, finish)
    return render_template('result.html', shortest_path=shortest_path, shortest_distance=shortest_distance, execution_time=execution_time)

if __name__ == '__main__':
    app.run(debug=True)
